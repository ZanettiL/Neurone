//Luca Zanetti
#include "neuron.cpp"

int main() {
	
	Neuron n(-70.0, 1, 10, 25.0);
	
	double inf;
	double sup;
	
	cout << "Entrez la borne inférieure puis la borne supérieure (entre 0 et 12) durant laquelle il y a du courant." << endl;
	cin >> inf;
	cin >> sup;
	if ((inf < sup) and (inf > 0) and (inf < 12) and (sup > 0) and (sup < 12)) {
		n.update(1, 0.1, 12, inf, sup);
	} else {
		cout << "Erreur." << endl;
	}
	
	return 0;
}

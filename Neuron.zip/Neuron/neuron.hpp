//Luca Zanetti
#include <iostream>
#include <cmath>
#include <list>
#include <iterator>
#include <fstream>

using namespace std;

class Neuron {

	public:
	Neuron(double, double, double, double);
	
	double getPotentiel() const;
	double getSimtime() const; 
	double getTau() const;
	double getI() const;
	double getR() const;
	
	void setPotentiel(double);
	void setSimtime(double);
	void setTau(double);
	void setI(double);
	void setR(double);
	
	bool isRefractory() const;
	void changeRefractory(bool);

	void update(int, double, double, double, double);
		
	private:
	double potentiel_membrane;
	int dendrites;
	list <int> time_occured;
	double simtime;
	double I;
	double tau;
	double r;
	bool periode_refractaire;

};

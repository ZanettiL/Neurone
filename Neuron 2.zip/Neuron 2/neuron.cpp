//Luca Zanetti
//Mon unité de référence est le mili.
//Valeurs numériques prises dans les références.
#include "neuron.hpp"
	
	Neuron::Neuron(double potentiel_membrane = 0.0, double I = 0.0, double tau = 0.0, double r = 0.0)
	: potentiel_membrane(potentiel_membrane), I(I), tau(tau), r(r) {}
	
	double Neuron::getPotentiel() const { return potentiel_membrane; } 
	double Neuron::getSimtime() const { return simtime; }
	double Neuron::getTau() const { return tau; }
	double Neuron::getI() const { return I; }
	double Neuron::getR() const { return r; }
	
	void Neuron::setPotentiel(double p) { potentiel_membrane = p; }
	void Neuron::setSimtime(double t) { simtime = t; }
	void Neuron::setTau(double t) { tau = t; }
	void Neuron::setI(double input) { I = input; }
	void Neuron::setR(double resistance ) { r = resistance; }
	
	bool Neuron::isRefractory() const { return periode_refractaire; }
	void Neuron::changeRefractory(bool b) { periode_refractaire = b; } 

	void Neuron::update(int n, double h, double stoptime, double inf, double sup, Neuron ne) {
		setSimtime(0.0);
		double spike_time(0.0);
		double Potentiel_Reset(-70.0); 
		double potentiel_seuil(20.0);
		double delai(1.0);
		double J;
		do {
			if (getPotentiel() > potentiel_seuil) {
				setPotentiel(0.0);
				changeRefractory(true);
				cout << "Période réfractaire." << endl;
					double temps_transfert(0.0);
					do {
						temps_transfert = temps_transfert + n*h;
						setSimtime(getSimtime() + n*h);
					} while (temps_transfert < delai);
					ne.setPotentiel(ne.getPotentiel() + J);
				do {
					setSimtime(getSimtime() + n*h);
					spike_time = spike_time + n*h;
				} while (spike_time < 2.0 - delai);
				setPotentiel(Potentiel_Reset);
				spike_time = 0.0;
				changeRefractory(false);
			} else {
				if ((getSimtime() > inf) and (getSimtime() < sup)) {
				setPotentiel(exp(-h/getTau())*getPotentiel() + getI()*getR()*(1 - exp(-h/getTau())));
				cout << "Potentiel : " << getPotentiel() << endl;
				setSimtime(getSimtime() + n*h);
			} else {
				setPotentiel(exp(-h/getTau())*getPotentiel());
				cout << "Potentiel : " << getPotentiel() << endl;
				setSimtime(getSimtime() + n*h);
				}
			}
		} while ((getSimtime() < stoptime));
	}
	
